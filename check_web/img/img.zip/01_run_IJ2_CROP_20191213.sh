date > nohup.log
/home/plantai/UTIL/fiji-linux64/Fiji.app/ImageJ-linux64 --ij2 --headless --run ./20191231_PSI_tomato_preproces_divide_CTW1_unit_pair_sample.ijm &
/home/plantai/UTIL/fiji-linux64/Fiji.app/ImageJ-linux64 --ij2 --headless --run ./20191231_PSI_tomato_preproces_divide_CTW2_unit_pair_sample.ijm &
/home/plantai/UTIL/fiji-linux64/Fiji.app/ImageJ-linux64 --ij2 --headless --run ./20191231_PSI_tomato_preproces_divide_CTW3_unit_pair_sample.ijm &
/home/plantai/UTIL/fiji-linux64/Fiji.app/ImageJ-linux64 --ij2 --headless --run ./20191231_PSI_tomato_preproces_divide_CTW4_unit_pair_sample.ijm
date > nohup.log


